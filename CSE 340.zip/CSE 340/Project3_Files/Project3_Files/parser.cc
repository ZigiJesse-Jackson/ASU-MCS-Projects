/*
 * Copyright (C) Rida Bazzi, 2016
 * Edited by Joshua Elkins, 2023
 *
 * Do not share this file with anyone
 */
#include <iostream>
#include <istream>
#include <vector>
#include <string>
#include <cctype>
#include <stdlib.h>
#include <string.h>

#include "lexer.h"
#include "inputbuf.h"
#include "parser.h"
using namespace std;

// Functions outside the class
struct scopeResolve {
 string scope;
 scopeResolve* next;
};

int gen_type = 4;
struct sTableEntry {
    string name;
    string scope;
    int pubpriv;
    int binNo = 3;
};

struct sTable {
sTableEntry* item;
sTable *prev; 
sTable *next;
bool printed = false;
};

sTable* symbolTable;
string currentScope;
string lResolve;
string rResolve;
int searchListReturnType = gen_type;
scopeResolve* scopeTable;
int currentPrivPub = 0;

void addScope(void){
    // creates a scope node and initializes it before passing it on ti scopeTable
    if(scopeTable == NULL){
        scopeResolve* newScopeItem = new scopeResolve;
        newScopeItem->scope = currentScope;
        newScopeItem->next = NULL;
        scopeTable = newScopeItem;
    // iterates through scope linked list, creates new node and initializes it before appending to scope linked list
    }else{
        scopeResolve* tempTable = scopeTable;
        while(tempTable->next != NULL){
            tempTable = tempTable->next;
        }   
        scopeResolve* newScopeItem = new scopeResolve;
        newScopeItem->scope = currentScope;
        newScopeItem->next = NULL;
        tempTable->next = newScopeItem;
    }
}

void deleteScope(void){
    // removes last node in scope linked list
        scopeResolve* tempTable = scopeTable;
        if(tempTable != NULL){
            if(tempTable->next == NULL){
                tempTable = NULL;
            }else{
                while(tempTable->next->next != NULL){
                    tempTable = tempTable->next;
                }
                currentScope = tempTable->scope;
                tempTable->next = NULL;   
            }
        }
}
/**
 * @brief 
    Adds new variable to symbol table.
    Symbol table is a linked list with nodes comprising of sTableEntrys
    each sTableEntry holds a variable name, the scope the variable was declared in
    and a visibility indicator (0 for public, 1 for private). Thus, the "symbol table"
    for a scope is just a range of sTable nodes.
 * 
 * @param lexeme 
 */
void addList(string lexeme, int binNo=gen_type){
   if(symbolTable == NULL){
      sTable* newEntry = new sTable;
      sTableEntry* newItem = new sTableEntry;
      newItem->name = lexeme;
      newItem->scope = currentScope;
      newItem->pubpriv = currentPrivPub;
      // 33 is ERROR enum
      if(gen_type==33) gen_type = 35;
      newItem->binNo = binNo;
      if(binNo == gen_type) gen_type++;

      newEntry->item = newItem;
      newEntry->next = NULL;
      newEntry->prev = NULL;
      symbolTable = newEntry;
      }else{
         sTable* temp = symbolTable;
         while(temp->next != NULL){
            temp = temp->next;
         }
         sTable* newEntry = new sTable;
        sTableEntry* newItem = new sTableEntry;
         newItem->name = lexeme;
         newItem->scope = currentScope;
         newItem->pubpriv = currentPrivPub;
         // 33 is ERROR enum
         if(gen_type==33) gen_type = 35;
         newItem->binNo = binNo;
        if(binNo == gen_type) gen_type++;

         newEntry->item = newItem;
         newEntry->next = NULL;
         newEntry->prev = temp;
         temp->next = newEntry;
   }
}

void printScope(void){
    sTable* temp = symbolTable;

    while(temp != NULL){
        string type;
        int type_no = temp->item->binNo;
        switch (temp->item->binNo)
        {
        case 0:
            type = "int";
            break;
        case 1:
            type = "real";
            break;
        case 2:
            type = "bool";
            break;
        
        default:
        type = "?";
            break;
        }
        if(type=="?" && temp->printed==false){
            cout<<temp->item->name;
            temp->printed = true;
            while(temp!=NULL){
                if(temp->printed==true || temp->item->binNo != type_no){
                    temp = temp->next;
                    
                }
                else{
                    cout<<", "<<temp->item->name;
                    temp->printed = true;
                    temp = temp->next;

                }
                
            }
            cout<<": "<<type<<" #"<<endl;
            temp = symbolTable;
        }
        else if(temp->printed == false){
            cout<<temp->item->name<<": "<<type<<" #"<<endl;
            temp->printed = true;
            temp = temp->next;
        }
        else temp = temp->next;
    }
}


void printList(void){
    sTable* temp = symbolTable;

    cout << "\n Printing Symbol Table \n";
    while(temp->next != NULL){
        cout << "\n Name: " << temp->item->name << " Scope: " << temp->item->scope << " Persmission: " << temp->item->pubpriv << " \n";
        temp = temp->next;
    }
    cout << "\n Name: " << temp->item->name << " Scope: " << temp->item->scope << " Persmission: " << temp->item->pubpriv << " \n";
}
/**
 * @brief 
 * Deletes all sTable nodes of currentScope.
 */
void deleteList(void){
    sTable* temp = symbolTable;
    
    if(temp!= NULL){
        while(temp->next != NULL && temp->item->scope!=currentScope){
            temp = temp->next;
        }
        if(temp->item->scope==currentScope){
            if(currentScope=="::"){
            temp = temp->prev;
            temp->next = NULL;
            }else{
                temp = NULL;
            }
        }
    }
}

/**
 * @brief 
 * 
 * @param iD variable name to find
 * @param lR indicates if variable is in lhs or rhs of an expression or declaration
 * @param binNo the token type of the variable
 */
bool searchList(string iD, int lR, int binNo){// add an argument to accept a type
    bool found = false;
    
    sTable* temp = symbolTable;
    if(temp == NULL){
        if(lR == 0){
            lResolve = "?";
        }else{
            rResolve = "?";
        }
    }else{
        int count = 0;
        while(temp->next != NULL){
            temp = temp->next;
            count++;
        }
        // variable has to have type binNo
        if(binNo>=0 && binNo<3){
            // look for variable in scopes 
            // iD and type have to match
            while(temp->prev != NULL){

                // found in earlier scope
                if(temp->item->name == iD && temp->item->binNo==binNo){
                    found = true;
                    if(lR == 0){
                            lResolve = currentScope;
                    }else{
                        rResolve = currentScope;
                    }
                    break;
                }
                temp = temp->prev;
            }

            // not found at global scope
                if(temp->prev == NULL && temp->item->name != iD && temp->item->binNo!=binNo){
                    if(lR == 0){
                        lResolve = "?";
                    }else{
                        rResolve = "?";
                    }
                    found = false;
                }else{
                    // found at global scope
                    found = true;
                }
        }
        // return first instance of variable with name iD
        else{
            // look for variable in scopes
            // iD and type have to match
            while(temp->prev!=NULL){                
                 // found in earlier scope
                if(temp->item->name == iD){
                    found = true;
                    searchListReturnType = temp->item->binNo;
                    if(lR == 0){
                        lResolve = currentScope;
                    }else{
                        rResolve = currentScope;
                    }
                    break;
                }
                temp = temp->prev;
            }
            // not found at global scope
                if(temp->prev == NULL && temp->item->name != iD){
                    if(lR == 0){
                        lResolve = "?";
                    }else{
                        rResolve = "?";
                    }
                    found = false;
                    searchListReturnType = gen_type;
                }else{
                    // found at global scope
                    found = true;
                    searchListReturnType = temp->item->binNo;
                }

        }
    }
    return found;
}

void updateType(int curr_type, int new_type){
    sTable* temp = symbolTable;

    while(temp != NULL)
    {
        if(temp->item->binNo == curr_type)
        {
            temp->item->binNo = new_type;
        }
        temp = temp->next;
    }
}



vector<string> decl_var;
// parse var_list
int Parser::parse_varlist(void){
    token = lexer.GetToken();
    int tempI;
    // addList(token.lexeme);
    // Check First set of ID
    if(token.token_type == ID){
        decl_var.push_back(token.lexeme);
        token = lexer.GetToken();
        if(token.token_type == COMMA){
            tempI = parse_varlist();
        }else if(token.token_type == COLON){
            tempTokenType = lexer.UngetToken(token);
        }else{
            return ERROR;
        }
    }else{
        return ERROR;
    }    
    return (0);
}

int Parser::parse_unaryOperator(void){
    token = lexer.GetToken();
    
    if(token.token_type == NOT){
        return NOT;
    }else{
        return ERROR;
    }
    // return(0);
}

int Parser::parse_binaryOperator(void){
    token = lexer.GetToken();
    if(token.token_type == PLUS  ){
        return token.token_type;
    }else if(token.token_type == MINUS ){
        return token.token_type;
    }else if(token.token_type == MULT){
        return token.token_type;
    }else if(token.token_type == DIV ){
        return token.token_type;
    }else if(token.token_type == GREATER){
        return token.token_type;
    }else if(token.token_type == LESS  ){
        return token.token_type;
    }else if(token.token_type == GTEQ ){
        return token.token_type;
    }else if(token.token_type == LTEQ){
        return token.token_type;
    }else if(token.token_type == EQUAL ){
        return token.token_type;
    }else if(token.token_type == NOTEQUAL){
        return token.token_type;
    }else{
        return ERROR;
    }
}



int Parser::parse_primary(void){
    token = lexer.GetToken();
    
    if(token.token_type == ID  ){
        // search list for the token. If token available then return the type of the token. if not then add the token to the list
        // make its scope = "h" and make its type = -1;
        // cout << "\n Rule parsed: primary -> ID\n";
        bool found = searchList(token.lexeme, 0, -2);
        // type of var has been set
        if(found){
            return searchListReturnType;
        }else{
            // var not yet added
            // add var to scope
            addList(token.lexeme);
            // return generic type      
            return gen_type-1;
        }
    }else if(token.token_type == NUM ){
        return 0;
    }
    else if(token.token_type == REALNUM){
        return 1;
    }else if(token.token_type == TR || token.token_type == FA){
        return 2;
    }
    
    return ERROR;
}

string expression_var;
int Parser::parse_expression(void){
    int tempI;
    int tempI1, tempI2;
    token = lexer.GetToken();
    
    if(token.token_type == ID || token.token_type == NUM || token.token_type == REALNUM || token.token_type == TR || token.token_type == FA ){
        tempTokenType = lexer.UngetToken(token);
        return parse_primary();
    }else if(token.token_type == PLUS || token.token_type == MINUS || token.token_type == MULT || token.token_type == DIV || token.token_type == GREATER || token.token_type == LESS || token.token_type == GTEQ || token.token_type == LTEQ || token.token_type == EQUAL || token.token_type == NOTEQUAL){
        if(token.token_type == PLUS || token.token_type == MINUS || token.token_type == MULT || token.token_type == DIV){
            tempI1 = parse_expression();
            if(tempI1 == ERROR) return ERROR;
            tempI2 = parse_expression();
            if(tempI2 == ERROR) return ERROR;
            // type mismatch
            if(tempI1 != tempI2 && (tempI1 <3 && tempI2 <3)){
                cout<<"TYPE MISMATCH "<< token.line_no<<" C2"<<endl;
                return ERROR;
            // undeclared generic types
            }else if(tempI1 > 2 && tempI2 > 2){
                updateType(tempI2, tempI1);
                return tempI1;
            }
            // first argumment is undeclared generic type
            else if(tempI1>2){
                updateType(tempI1, tempI2);
                return tempI2;
            // second argument is undeclared generic type
            }else if(tempI2>2){
                updateType(tempI2, tempI1);
                return tempI1;
            // both types are the same
            }else {
                return tempI1;
            }
        }
        else if(token.token_type == GREATER || token.token_type == LESS || token.token_type == EQUAL || token.token_type == GTEQ || token.token_type == LTEQ || token.token_type == NOTEQUAL){
            tempI1 = parse_expression();
            if(tempI1 == ERROR) return ERROR;
            tempI2 = parse_expression();
            if(tempI2 == ERROR) return ERROR;
            // type mismatch
            if(tempI1 != tempI2 && (tempI1 < 3 && tempI2 < 3)){
                cout<<"TYPE MISMATCH "<< token.line_no<<" C2"<<endl;
                return ERROR;
            // undeclared type
            }else if(tempI1>2 && tempI2 > 2){
                updateType(tempI2, tempI1);
                return 2;
            }
            // first argumment is undeclared type
            else if(tempI1>2 && tempI2!=ERROR ){
                 updateType(tempI1, tempI2);
                return 2;
            // second argument is undeclared type
            }else if(tempI2>2 && tempI1!=ERROR){
                 updateType(tempI2, tempI1);
                return 2;
            // both types are the same
            }else {
                return 2;
            }
        }
    }else if(token.token_type == NOT){
    // tempTokenType = lexer.UngetToken(token);
        tempI1 = 2;
        tempI2 = parse_expression();
        if(tempI2==2){
            return 2;
        }else if(tempI2>2){
            updateType(tempI2, 2);
            return 2;
        }else{
            cout<<"TYPE MISMATCH "<< token.line_no<<" C3"<<endl;
            return ERROR;
        }
        //if parse expression returns an ID and type of that ID is -1 then make it 2 by using search list
        // if tempI2 != 2 and != -1 then Type mismatch token.line_no C3????
    }
    return ERROR;

}


int Parser::parse_assstmt(void){
    int tempI;
    token = lexer.GetToken();

    if(token.token_type == ID){
        // search for the token in the searchList --> the token is available, leftType = type of the available token
        // it is not available in the searchList, add the token to the list, make its type = -1; make its scope = "h".
        string lhs = token.lexeme;
        token = lexer.GetToken();
        if(token.token_type == EQUAL){
             token = lexer.GetToken();  
             if(token.token_type == ID || token.token_type == NUM || token.token_type == REALNUM || token.token_type == TR || token.token_type == FA || token.token_type == PLUS || token.token_type == MINUS || token.token_type == MULT || token.token_type == DIV || token.token_type == LESS || token.token_type == GREATER || token.token_type == GTEQ || token.token_type == LTEQ || token.token_type == EQUAL || token.token_type == NOTEQUAL || token.token_type == NOT){
                tempTokenType = lexer.UngetToken(token);
                bool found = searchList(lhs, 0, -2);
                int lhs_type = searchListReturnType;
                if(!found){
                    addList(lhs);
                }
                tempI = parse_expression();
                if(tempI == ERROR) return ERROR;
                // lhs is not already declared 
                
                // lhs is already declared
                // lhs type is undefined and rhs type is valid
                else if(lhs_type>2 || !found){
                    updateType(lhs_type, tempI);
                }
                else if(tempI>2 && lhs_type<3){
                    updateType(tempI, lhs_type);
                    tempI = lhs_type;
                }
                // lhs type is defined and the same as rhs type
                else if(lhs_type == tempI){
                    tempI;
                }
                // lhs not the same type as rhs
                else{
                    cout<<"TYPE MISMATCH "<< token.line_no<<" C1"<<endl;
                    return ERROR;
                }
                
                //rType right type of an assigment tempI.
                //check for C1. if ltype == rtype then fine if not then TYPE MISMATCH token.line_no C1
                // if any one of lType or rType is -1 then should not throw type mismatch. 
                // if lType != -1 && rType is -1 then you search for left ID token to extract its type. searchList should return type. 
                // you have to use search list again with the right token to update the right token's type to lType 
                token = lexer.GetToken();
                if(token.token_type == SEMICOLON){
                    return tempI;

                }else{
                    return ERROR;  
                 }
             }else{
                return ERROR;
             }  
        }else{
            return ERROR; 
        }  
    }else{
        return ERROR; 
    }
    // return(0);
}

int Parser::parse_case(void){
    int tempI;
    token = lexer.GetToken();

    if(token.token_type == CASE ){
        token = lexer.GetToken();
        if(token.token_type == NUM){
            token = lexer.GetToken();
            if(token.token_type == COLON){
                return parse_body();
            }else{
                return ERROR;
            }
        }else{
            return ERROR;
        }
    }else{
        return ERROR;
    }
}

int Parser::parse_caselist(void){
    
    int tempI;
    token = lexer.GetToken();
    if(token.token_type == CASE){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_case();
        if(tempI == ERROR) return tempI;
        token = lexer.GetToken();
        if(token.token_type == CASE){
            tempTokenType = lexer.UngetToken(token);
            return parse_caselist();
        }else if(token.token_type == RBRACE){
            tempTokenType = lexer.UngetToken(token);
        }
    }
    return(0);
}


int Parser::parse_switchstmt(void){
    int tempI;
    
    token = lexer.GetToken();
    if(token.token_type == SWITCH){
        token = lexer.GetToken();
        if(token.token_type == LPAREN){
            tempI = parse_expression();
            if(tempI == ERROR) return ERROR;
            // if tempI != INT then throw type error
            // else if tempI = -1 ==> parse_expresssion returned an ID, then go and change using searchList the type of ID to 1.
            // if(!searchList(lexeme, 0, -2)){
            //     addList(lexeme, 1);
            // }
            if(tempI>2){
                updateType(tempI, 0);
            }else if(tempI!=0){
                cout<<"TYPE MISMATCH "<< token.line_no<<" C5"<<endl;
                return ERROR;
            }
            token = lexer.GetToken();
            if(token.token_type == RPAREN){
                token = lexer.GetToken();
                if(token.token_type == LBRACE){
                    tempI = parse_caselist();
                    if(tempI == ERROR) return ERROR;
                    token = lexer.GetToken();
                    if(token.token_type == RBRACE){
                        return (0);        
                    }else{
                        return ERROR;
                    }   
                }else{
                    return ERROR;
                }
                
            }else{
                return ERROR;
            }
        }else{
            return ERROR;
        }    
    }else{
        return ERROR;
    }
}


int Parser::parse_whilestmt(void){
    int tempI;
    token = lexer.GetToken();

    if(token.token_type == WHILE){
        token = lexer.GetToken();
        if(token.token_type == LPAREN){
            tempI = parse_expression();
            if(tempI == ERROR) return ERROR;
            // if tempI != bool then throw type error
            // else if tempI = -1 ==> parse_expresssion retunred an ID, then go and change using searchList the type of ID to 2.
            if(tempI>2){
                updateType(tempI, 2);
            }else if(tempI!=2){
                cout<<"TYPE MISMATCH "<< token.line_no<<" C4"<<endl;
                return ERROR;
            }
            token = lexer.GetToken();
            if(token.token_type == RPAREN){
                return parse_body();
            }else{
                return ERROR;
            }
        }else{
            return ERROR;
        }    
    }else{
        return ERROR;
    }
}

int Parser::parse_ifstmt(void){
    int tempI;
    token = lexer.GetToken();

    if(token.token_type == IF){
        token = lexer.GetToken();
        if(token.token_type == LPAREN){
            tempI = parse_expression();
            if(tempI == ERROR) return ERROR;
            // if tempI != bool then throw type error
            // else if tempI = -1 ==> parse_expresssion retunred an ID, then go and change using searchList the type of ID to 2.
            if(tempI>2){
                updateType(tempI, 2);
            }else if(tempI!=2){
                cout<<"TYPE MISMATCH "<< token.line_no<<" C4"<<endl;
                return ERROR;
            }
            token = lexer.GetToken();
            if(token.token_type == RPAREN){
                return parse_body();
            }else{
                return ERROR;
            }
        }else{
            return ERROR;
        }    
    }else{
        return ERROR;
    }
}

int Parser::parse_stmt(void){
    int tempI;
    token = lexer.GetToken();

    if(token.token_type == ID){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_assstmt(); 

    }else if(token.token_type == IF){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_ifstmt();
    }else if(token.token_type == WHILE){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_whilestmt();
    }else if(token.token_type == SWITCH){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_switchstmt();
    }else{
        return ERROR;
    }
    return tempI;
}

int Parser::parse_stmtlist(void){
    token = lexer.GetToken();
    int tempI;

    if(token.token_type == ID || token.token_type == IF || token.token_type == WHILE || token.token_type == SWITCH){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_stmt();
        if(tempI==ERROR) return ERROR;
        token = lexer.GetToken();
        if(token.token_type == ID || token.token_type == IF || token.token_type == WHILE || token.token_type == SWITCH){
            tempTokenType = lexer.UngetToken(token);
            return parse_stmtlist();
        }else if (token.token_type == RBRACE){
            tempTokenType = lexer.UngetToken(token);
            return tempI;
        }
    }
    return ERROR;
    
}



int Parser::parse_body(void){
    token = lexer.GetToken();
    int tempI;
    
        if(token.token_type == LBRACE){
            tempI = parse_stmtlist();
            token = lexer.GetToken();
            if(token.token_type == RBRACE){
                return tempI;
            }else{
                return ERROR;
            }    
        }else if(token.token_type == END_OF_FILE){
            tempTokenType = lexer.UngetToken(token);
            return(0);
        }else{
            return ERROR;
        }
}

// parse scope end
int Parser::parse_typename(void){
    token = lexer.GetToken();
    switch(token.token_type){
        case(INT):
            return 0;
        case(REAL):
            return 1;
        case(BOO):
            return 2;
        default:
            return ERROR;
    }
}

int Parser::parse_vardecl(void){
    int tempI;
    token = lexer.GetToken();

    if(token.token_type == ID){
        tempTokenType = lexer.UngetToken(token);
        parse_varlist();
        token = lexer.GetToken();
        if(token.token_type == COLON){
            tempI = parse_typename();
            //use the searchList to update the types of variables that are already in the symbolTable
            if(tempI == ERROR){
                return ERROR;
            }
            token = lexer.GetToken();
            if(token.token_type == SEMICOLON){
                // added declared var
                for(int i=0;i<decl_var.size();i++){
                    addList(decl_var[i], tempI);
                }
                decl_var.clear();
                return tempI;
            }else{
                return ERROR;
            }
        } else{
            return ERROR;
        } 
    }else{
        return ERROR;
    }
}

int Parser::parse_vardecllist(void){
    int tempI;    
    token = lexer.GetToken();

    while(token.token_type == ID){
        tempTokenType = lexer.UngetToken(token);
        tempI = parse_vardecl();
        token = lexer.GetToken();
        if(tempI == ERROR) return ERROR;
    }
    tempTokenType = lexer.UngetToken(token);
    return(0);
}


string global = "::";
// parse global vars
int Parser::parse_globalVars(void){
    token = lexer.GetToken();
    int tempI;
    
    //check first set of var_list SEMICOLON
    if(token.token_type == ID){
        tempTokenType = lexer.UngetToken(token);
        currentPrivPub = 0;
        tempI = parse_vardecllist();
    } else{
        return ERROR;
    }
    return tempI;
}


int Parser::parse_program(void){
    token = lexer.GetToken();
    int tempI;

    while (token.token_type != END_OF_FILE)
    {
        // Check first set of global_vars scope
            if(token.token_type == ID){
            tempTokenType = lexer.UngetToken(token);
            tempI = parse_globalVars();
            if(tempI==ERROR) return ERROR;
            tempI = parse_body();
            if(tempI==ERROR) return ERROR;
            }else if(token.token_type == LBRACE){
                tempTokenType = lexer.UngetToken(token);
                tempI = parse_body();
                if(tempI==ERROR) return ERROR;
            }else if(token.token_type == END_OF_FILE){
                return(0);
            }else{
                return ERROR;
            }
        token = lexer.GetToken();
    }
    return(0);
}

char null[] = "NULL";
int main()
{
    int i;
    Parser* parseProgram = new Parser();
    i = parseProgram->parse_program();
    if(i!=ERROR){
        printScope();
    }
    // cout << "\n End of Program \n";
}
